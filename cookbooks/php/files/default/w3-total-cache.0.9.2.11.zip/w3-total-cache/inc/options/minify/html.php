<?php if (!defined('W3TC')) die(); ?>
<?php $this->checkbox('minify.html.strip.crlf', false, 'html_') ?> <?php _e('Line break removal', 'w3-total-cache'); ?></label><br />
